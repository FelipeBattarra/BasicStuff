module.exports = function (api) {
  api.render('./templates')
}
