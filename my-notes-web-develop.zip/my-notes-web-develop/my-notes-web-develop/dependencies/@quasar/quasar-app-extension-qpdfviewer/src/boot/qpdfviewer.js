import QPdfviewer from '@quasar/quasar-app-extension-qpdfviewer/src/component/QPdfviewer.js'

export default ({ app }) => {
  app.component('QPdfviewer', QPdfviewer)
}
