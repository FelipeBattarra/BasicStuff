module.exports = function (api) {
  api.removePath('public/pdfjs')
}
