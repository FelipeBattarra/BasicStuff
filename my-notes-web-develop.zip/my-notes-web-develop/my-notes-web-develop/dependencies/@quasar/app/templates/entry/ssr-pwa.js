/**
 * THIS FILE IS GENERATED AUTOMATICALLY.
 * DO NOT EDIT.
 **/

export const isRunningOnPWA = typeof window !== 'undefined' &&
  document.body.getAttribute('data-server-rendered') === null
